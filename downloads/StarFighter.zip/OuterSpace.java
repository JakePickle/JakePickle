import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.awt.Toolkit;

@SuppressWarnings("serial")
public class OuterSpace extends Canvas implements KeyListener, Runnable
{
	public Ship ship;
	ArrayList<Alien> aliens = new ArrayList<Alien>();
	ArrayList<Ammo> ammo = new ArrayList<Ammo>();
	private int level = 1;
	private int shooter = 0;
	private int moveCounter=7;
	private String ammoInertia = "UP";
	private boolean[] keys;
	private BufferedImage back;
	private int score = 0;
	private Boolean gameOver = false;
	private int alienSpawnMin=0,spawnLevel=0;

	public OuterSpace()
	{
		setBackground(Color.black);
		keys = new boolean[5];
		ship = new Ship();
		aliens.add(new Alien());
		this.addKeyListener(this);
		new Thread(this).start();
		setVisible(true);
	}

   public void update(Graphics window)
   {
	   paint(window);
   }

	public void paint( Graphics window )
	{
		Graphics2D twoDGraph = (Graphics2D)window;
		if(back==null)
		   back = (BufferedImage)(createImage(getWidth(),getHeight()));
		Graphics graphToBack = back.createGraphics();
		graphToBack.setColor(Color.BLUE);
		graphToBack.drawString("StarFighter ", 25, 50 );
		graphToBack.setColor(Color.BLACK);
		graphToBack.fillRect(0,0,Toolkit.getDefaultToolkit().getScreenSize().width,Toolkit.getDefaultToolkit().getScreenSize().height);
		
		//sets color to red
		window.setColor(Color.RED);
		
		if(keys[0])
		{
			ship.move("LEFT");
			ammoInertia="LEFT";
		}else{
			ammoInertia="UP";
		}
		if(keys[1])
		{
			ship.move("RIGHT");
			ammoInertia="RIGHT";
		}else{
			if(!ammoInertia.equals("LEFT"))
				ammoInertia="UP";
		}
		if(keys[2])
		{
			ship.move("UP");
		}
		if(keys[3])
		{
			ship.move("DOWN");
		}
		if(keys[4])
		{
			if(shooter==0){
				if(ammoInertia.equals("UP")){
					ammo.add(new Ammo(ship));
					shooter=3;
				}
				else if(ammoInertia.equals("LEFT")){
					ammo.add(new Ammo(ship,ammoInertia));
					shooter=3;					
				}
				else{
					ammo.add(new Ammo(ship,ammoInertia));
					shooter=3;					
				}
			}else{
				shooter--;
			}		
		}
		for (Ammo shot : ammo)
		{
			{
				shot.draw(graphToBack);
				shot.move("string");
				//if(/*pos is not in window size*/){
					//may have to remove backwards, I dont feel like it
				//}
			}
		}
		for(Alien pants: aliens){
			for(Ammo shirts: ammo){
				if(Math.abs(pants.getX()-shirts.getX())<=pants.getWidth()/2 && Math.abs(pants.getY()-shirts.getY())<=pants.getHeight()/2){
					aliens.remove(pants);
					score+=10;
				}	
			}
		}
		for(Alien toDraw: aliens){
			toDraw.draw(graphToBack);
		}

		if(aliens.size()<=alienSpawnMin){
			level++;
			spawnLevel++;
			for(int i=level;i>0;i--){
				aliens.add(new Alien());
			}
		}
		
		if(spawnLevel==4){
			alienSpawnMin+=4;
			spawnLevel=0;
		}
		
		for(Alien toMove: aliens){
			if((int)(Math.random()*10)>=moveCounter){
				toMove.move("string"); 
				moveCounter=6;
			}else{
				moveCounter--;
			}
			if(toMove.getY()>=Toolkit.getDefaultToolkit().getScreenSize().height-100){
				gameOver=true;
			}
		}
		ship.draw(graphToBack);
		twoDGraph.drawImage(back, null, 0, 0);
		
		window.drawString("Points "+score, Toolkit.getDefaultToolkit().getScreenSize().width-100,10);
		
		if(gameOver){
			window.drawString("GAME OVER", Toolkit.getDefaultToolkit().getScreenSize().width/2,Toolkit.getDefaultToolkit().getScreenSize().height/2);
		}
		
		window.drawLine(0,Toolkit.getDefaultToolkit().getScreenSize().height-100,Toolkit.getDefaultToolkit().getScreenSize().width,Toolkit.getDefaultToolkit().getScreenSize().height-100);
	}

	public void keyPressed(KeyEvent e)
	{
		if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A)
		{
			keys[0] = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D)
		{
			keys[1] = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W)
		{
			keys[2] = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S)
		{
			keys[3] = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_SPACE)
		{
			keys[4] = true;
		}
		repaint();
	}

	public void keyReleased(KeyEvent e)
	{
		if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A)
		{
			keys[0] = false;
		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D)
		{
			keys[1] = false;
		}
		if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W)
		{
			keys[2] = false;
		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S)
		{
			keys[3] = false;
		}
		if (e.getKeyCode() == KeyEvent.VK_SPACE)
		{
			keys[4] = false;
		}
		repaint();
	}
	
	public void keyTyped(KeyEvent e) 
	{
		
	}

    public void run()
    {
   	try
   	{
   		while(true)
   		{
   		    Thread.currentThread();
			Thread.sleep(20);
            repaint();      
            
         }
      }catch(Exception e)
      {
      }
  	}
}

