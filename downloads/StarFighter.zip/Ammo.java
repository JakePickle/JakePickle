import java.awt.Graphics;
import java.awt.Image;
import java.io.File;

import javax.imageio.ImageIO;


public class Ammo extends MovingThing
{
	private int speed;
	private Image image;
	private String direction;
	private Ship player;
	
	public Ammo(Ship ship)
	{
		this(ship.getX(),ship.getY()-5,15);
		direction="UP";
		player=ship;
	}
	
	public Ammo(Ship ship, String dir)
	{
		this(ship.getX(),ship.getY()-5,15);
		direction = dir;
		player=ship;
	}

	public Ammo(int x, int y)
	{
		this(x,y,15);
	}

	public Ammo(int x, int y, int s)
	{
		super(x,y,10,10);
		speed = s;
		try
		{
			image = ImageIO.read(new File("ammo.jpg"));
		}
		catch(Exception e)
		{
			//feel free to do something here
		}
	}

	public void setSpeed(int s)
	{
	   speed = s;
	}

	public int getSpeed()
	{
	   return speed;
	}

	public void draw( Graphics window )
	{
		window.drawImage(image,getX()+20,getY(),10,10,null);
	}
	
	public void move(String string){
		if(direction.equals("UP")){
			setY(getY() - speed);
		}else if(direction.equals("LEFT")){
			setY(getY() - speed);
			setX(getX() - (player.getSpeed()/2));
		}else{
			setY(getY() - speed);
			setX(getX() + (player.getSpeed()/2));
		}
	}
	public String toString()
	{
		return "What I do here?";
	}
}
