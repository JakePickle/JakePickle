#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <vector>
#include "graph.h"

using namespace std;

vector<vector<Path> > floydWarshall(Graph g);
void readInput(Graph &g,bool weighted);
void outputDegreeDistribution(Graph g);
void shortestPathDisribution(vector<vector<Path> > paths,bool directed);//Also graph diameter
void closenessCentrality(vector<vector<Path> > paths,bool directed);
void betweennessCentralityVertex(vector<vector<Path> > paths,Graph g);
void betweennessCentralityEdge(vector<vector<Path> > paths,Graph g);
void betweennessCentralityEdgeWeighted(vector<vector<Path> > paths,Graph g);
void communityDetection(vector<vector<Path> > paths,Graph g);

int main()
{
  Graph graphUndirUnwgt("Graph One",false);
  Graph graphDirUnwgt("Graph Two",true);
  Graph graphUndirWgt("Graph Tree",false);
  Graph graphDirWgt("Graph Four",true);

  vector<vector<Path> > graphUndirUnwgtPaths;
  vector<vector<Path> > graphDirUnwgtPaths;
  vector<vector<Path> > graphUndirWgtPaths;
  vector<vector<Path> > graphDirWgtPaths;

  readInput(graphUndirUnwgt,false);
  readInput(graphDirUnwgt,false);
  readInput(graphUndirWgt,true);
  readInput(graphDirWgt,true);

  graphUndirUnwgt.getInDegree();
  graphUndirWgt.getInDegree();
  graphDirWgt.getInDegree();
  graphDirUnwgt.getInDegree();

  graphUndirUnwgt.getOutDegree();
  graphUndirWgt.getOutDegree();
  graphDirWgt.getOutDegree();
  graphDirUnwgt.getOutDegree();

  cout << "Start Graph One" << endl;
  //Graph One undirected unweighted
  outputDegreeDistribution(graphUndirUnwgt);
  graphUndirUnwgtPaths=floydWarshall(graphUndirUnwgt);
  shortestPathDisribution(graphUndirUnwgtPaths,false);
  closenessCentrality(graphUndirUnwgtPaths,false);
  betweennessCentralityVertex(graphUndirUnwgtPaths,graphUndirUnwgt);
  betweennessCentralityEdge(graphUndirUnwgtPaths,graphUndirUnwgt);
  communityDetection(graphUndirUnwgtPaths,graphUndirUnwgt);

  cout << "Start Graph Two" << endl;
  //Graph Two directed unweighted
  outputDegreeDistribution(graphDirUnwgt);
  graphDirUnwgtPaths=floydWarshall(graphDirUnwgt);
  shortestPathDisribution(graphDirUnwgtPaths,true);
  closenessCentrality(graphDirUnwgtPaths,true);
  betweennessCentralityVertex(graphDirUnwgtPaths,graphDirUnwgt);
  betweennessCentralityEdge(graphDirUnwgtPaths,graphDirUnwgt);
  communityDetection(graphDirUnwgtPaths,graphDirUnwgt);

  cout << "Start Graph Tree" << endl;
  //Graph Tree undirected weighted
  outputDegreeDistribution(graphUndirWgt);
  //graphUndirWgtPaths=floydWarshall(graphUndirWgt);
  //shortestPathDisribution(graphUndirWgtPaths,false);
  betweennessCentralityEdgeWeighted(graphUndirWgtPaths,graphUndirWgt);
  //communityDetection(graphUndirWgtPaths,graphUndirWgt);

  cout << "Start Graph Four" << endl;
  //Graph Four directed weighted
  outputDegreeDistribution(graphDirWgt);
  //graphUndirWgtPaths=floydWarshall(graphDirWgt);
  //shortestPathDisribution(graphDirWgtPaths,true);
  betweennessCentralityEdgeWeighted(graphDirWgtPaths,graphDirWgt);
  //communityDetection(graphDirWgtPaths,graphDirWgt);


  cout<<"Done."<<endl;
  cout<<"Press Return to Continue."<<endl;
  cin.ignore();
  return 0;
}

void readInput(Graph &g,bool weighted)
{
  ifstream file("graph.txt");
  string source,target,junk;
  int weight=0;

  getline(file,junk);
  while(!file.eof())
  {
    getline(file,source,',');
    getline(file,target,',');
    file>>weight;
    getline(file,junk);
    if(source!="")
    {
      Node s = Node(source);
      Node t = Node(target);
      if(weighted)
        g.addEdge(s,t,weight);
      else
        g.addEdge(s,t);
    }
  }
  file.close();
  return;
}

vector<vector<Path> > floydWarshall(Graph g)
{
  /*----------------INITIALIZATION-----------------*/

  vector<vector<Path> > shortestPathGraph; //all the paths
  int nodeSize = g.nodes.size();
  int edgeSize = g.edges.size();
  
  for(int i=0;i<nodeSize;i++)
  {
    vector<Path> tempPath;
    for(int j=0;j<nodeSize;j++)
    {
      if(i==j)
        tempPath.push_back(Path(g.nodes[i]));
      else
        tempPath.push_back(Path());
    }
    shortestPathGraph.push_back(tempPath);
  }

  /*---------------SETTING NODE ID'S---------------*/

  for (int bal = 0; bal < nodeSize; ++bal)
  {
    g.nodes[bal].ID=bal;
  }

  for (int i = 0; i < nodeSize; ++i)
  {
    for (int j = 0; j < nodeSize; ++j)
    {
      shortestPathGraph[i][j].source.ID=i;
      shortestPathGraph[i][j].target.ID=j;
    }
  }

  for(int F=0;F<edgeSize;F++) 
  {
    for (int i = 0; i < nodeSize; ++i)
    {
      for (int j = 0; j < nodeSize; ++j)
      {
        if (shortestPathGraph[i][j].target.name==g.edges[F].source.name)
        {
          g.edges[F].source.ID=shortestPathGraph[i][j].target.ID;
        }
        if (shortestPathGraph[i][j].target.name==g.edges[F].target.name)
        {
          g.edges[F].target.ID=shortestPathGraph[i][j].target.ID;
        }
      }
    }
  }

  /*-----------------SHORTEST PATH-----------------*/

  for(int i=0;i<edgeSize;i++) 
  {
    Edge e = g.edges[i]; //current edge
    shortestPathGraph[e.source.ID][e.target.ID]=Path(e.source,e.target,e);
  }

  for(int k=0;k<nodeSize;k++)
  {
    //cout<<"Currently on Iteration: "<<k<<endl;  
    for(int i=0;i<nodeSize;i++) //row or src
    {
      for(int j=0;j<nodeSize;j++) //col or tgt
      {
        if(i!=j&&shortestPathGraph[i][k].exist()&&shortestPathGraph[k][j].exist())
        {  
          if((shortestPathGraph[i][j].getWeight()>shortestPathGraph[i][k].getWeight()+shortestPathGraph[k][j].getWeight())||(!shortestPathGraph[i][j].exist()))
          {
            //if source ID < k
            shortestPathGraph[i][j]=shortestPathGraph[i][k]+shortestPathGraph[k][j];
          }
        }
      }
    }
  }

  /*------------------OUTPUT DATA------------------*/
  string stuff;
  if(g.directed&&g.weighted)
  {
    stuff = "outputDirectedWeighted.csv";
  }
  else if(g.directed&&(!g.weighted))
  {
    stuff = "outputDirected.csv";
  }
  else if((!g.directed)&&g.weighted)
  {
    stuff = "outputWeighted.csv";
  }
  else
  {
    stuff= "output.csv";
  }

  ofstream out(stuff.c_str());

  //ofstream out("output.csv");
  for(int i=0;i<nodeSize;i++)
  {
    for(int j=0;j<nodeSize;j++)
    {
      out<<shortestPathGraph[i][j]<<",";
    }
    out<<"\n";
  }
  out.close();
  return shortestPathGraph;
}

void outputDegreeDistribution(Graph g)
{
  vector<int> spotsIn;
  vector<int> spotsOut;
  int maxIn=0;
  int maxOut=0;

  for (int i = 0; i < g.nodes.size(); ++i)
  {
    if(g.nodes[i].inDegree>maxIn)
      maxIn=g.nodes[i].inDegree;
  }

  for (int i = 0; i < g.nodes.size(); ++i)
  {
    if(g.nodes[i].outDegree>maxOut)
      maxOut=g.nodes[i].outDegree;
  }

  for (int i = 0; i < g.nodes.size(); ++i)
  {
    if(g.nodes[i].inDegree==maxIn)
      spotsIn.push_back(i);
  }

  for (int i = 0; i < g.nodes.size(); ++i)
  {
    if(g.nodes[i].outDegree==maxOut)
      spotsOut.push_back(i);
  }

  if(spotsIn.size()==1)
  {
    cout << "The node with maximum in degree on graph " << g.name << " is " << g.nodes[spotsIn[0]].name << "!"<<endl<<endl;
  }
  else
  {
    cout << "The nodes with maximum in degree on graph " << g.name << " are:" << endl;
    for (int i = 0; i < spotsIn.size(); ++i)
    {
      cout << g.nodes[i].name << endl;
    }
    cout << endl;
  }

  if(spotsOut.size()==1)
  {
    cout << "The node with maximum out degree on graph " << g.name << " is " << g.nodes[spotsOut[0]].name << "!"<<endl<<endl;
  }
  else
  {
    cout << "The nodes with maximum out degree on graph " << g.name << " are:" << endl;
    for (int i = 0; i < spotsOut.size(); ++i)
    {
      cout << g.nodes[i].name << endl;
    }
    cout << endl;
  }

  string stuff;
  if(g.directed&&g.weighted)
  {
    stuff = "DegreeDistributionDirectedWeighted.csv";
  }
  else if(g.directed&&(!g.weighted))
  {
    stuff = "DegreeDistributionDirected.csv";
  }
  else if((!g.directed)&&g.weighted)
  {
    stuff = "DegreeDistributionWeighted.csv";
  }
  else
  {
    stuff= "DegreeDistribution.csv";
  }

  ofstream outFile(stuff.c_str());

  outFile << "in degree" << "," << "out degree" << endl;

  for (int i = 0; i < g.nodes.size(); ++i)
  {
    outFile << g.nodes[i].inDegree << "," << g.nodes[i].outDegree << endl;
  }
  outFile.close();
  return;
}

void shortestPathDisribution(vector<vector<Path> > paths,bool directed)
{
  int nodeSize=paths.size();

  vector<Path> spots;
  int max=0;

  for (int i = 0; i < nodeSize; ++i)
  {
    for (int j = 0; j < nodeSize; ++j)
    {
      if(paths[i][j].exist()&&paths[i][j].getWeight()>max)
        max=paths[i][j].getWeight();
    }
  }
  for (int i = 0; i < nodeSize; ++i)
  {
    for (int j = 0; j < nodeSize; ++j)
    {
      if(paths[i][j].getWeight()==max)
        spots.push_back(paths[i][j]);
    }
  }

  if(spots.size()==1)
  {
    cout << "The shortest path with maximum weight is " << spots[0] << "!"<<endl<<endl;
  }
  else
  {
    cout << "The shortest paths with maximum weight are:" << endl;
    for (int i = 0; i < spots.size(); ++i)
    {
      cout << spots[i] << endl;
    }
    cout << endl;
  }


  string stuff;
  if(directed)
  {
    stuff = "UnweightedDirectedPathDistribution.csv";
  }
  else
  {
    stuff= "UnweightedUndirectedPathDistribution.csv";
  }

  ofstream outFile(stuff.c_str());

  outFile << "Path Weight" << endl;

  for (int i = 0; i < nodeSize; ++i)
  {
    for (int j = 0; j < nodeSize; ++j)
    {
      outFile << paths[i][j].getWeight() << endl;
    }
  }
  outFile.close();
  return;
}

void closenessCentrality(vector<vector<Path> > paths,bool directed)
{
  int nodeSize=paths.size();
  vector<int> closenessValues;

  for (int i = 0; i < nodeSize; ++i)
  {
    double sum = 0;
    double count = 0;
    for (int j = 0; j < nodeSize; ++j)
    {
      if (paths[i][j].exist())
      {
        sum+=paths[i][j].getWeight();
        count++;
      }
    }
    double avg = (sum/count);
    closenessValues.push_back(avg);
  }

  string stuff;
  if(directed)
  {
    stuff = "UnweightedDirectedClosenessDistribution.csv";
  }
  else
  {
    stuff= "UnweightedUndirectedClosenessDistribution.csv";
  }

  ofstream outFile(stuff.c_str());
  for (int i = 0; i < closenessValues.size(); ++i)
  {
    outFile << i << "," << closenessValues[i] << endl;
  }
  outFile.close();

  vector<string> spots;
  int max = 0;
  for (int i = 0; i < closenessValues.size(); ++i)
  {
    if(closenessValues[i]>max)
      max=closenessValues[i];
  }

  for (int i = 0; i < closenessValues.size(); ++i)
  {
    if(closenessValues[i]==max)
      spots.push_back(paths[i][0].edges[0].source.name);
  }

  if(spots.size()==1)
  {
    cout << "The vertex with the highest closeness value is " << spots[0] << " with a value of " << max << "!"<<endl<<endl;
  }
  else
  {
    cout << "The vertices with the highest closeness value are:" << endl;
    for (int i = 0; i < spots.size(); ++i)
    {
      cout << spots[i] << endl;
    }
    cout << "\nwith a value of " << max << endl;
  }
  return;
}

void betweennessCentralityVertex(vector<vector<Path> > paths,Graph g)
{
  int nodeSize=paths.size();
  vector<int> betweennessValues;

  for (int k = 0; k < nodeSize; ++k)
  {
    int count = 0;
    for (int i = 0; i < nodeSize; ++i)
    {   
      for (int j = 0; j < nodeSize; ++j)
      {
        for (int pants = 0; pants < paths[i][j].edges.size(); ++pants)
        {
          if(paths[i][j].edges[pants].source.name==g.nodes[k].name)
          {
            count++;
            pants = INT_MAX;//kick it outside of pants loop
          }
          else if(paths[i][j].edges[pants].target.name==g.nodes[k].name)
          {
            count++;
            pants = INT_MAX;//kick it outside of pants loop
          } 
        }     
      }
    }
    betweennessValues.push_back(count);
  }

  string stuff;
  if(g.directed)
  {
    stuff = "UnweightedDirectedBetweennessVertexDistribution.csv";
  }
  else
  {
    stuff= "UnweightedUndirectedBetweennessVertexDistribution.csv";
  }

  ofstream outFile(stuff.c_str());
  for (int i = 0; i < betweennessValues.size(); ++i)
  {
    outFile << i << "," << betweennessValues[i] << endl;
  }
  outFile.close();

  vector<string> spots;
  int max = 0;
  for (int i = 0; i < betweennessValues.size(); ++i)
  {
    if(betweennessValues[i]>max)
      max=betweennessValues[i];
  }

  for (int i = 0; i < betweennessValues.size(); ++i)
  {
    if(betweennessValues[i]==max)
      spots.push_back(paths[i][0].edges[0].source.name);
  }

  if(spots.size()==1)
  {
    cout << "The vertex with the highest betweenness value is " << spots[0] << " with a value of " << max << "!"<<endl<<endl;
  }
  else
  {
    cout << "The vertices with the highest betweenness value are:" << endl;
    for (int i = 0; i < spots.size(); ++i)
    {
      cout << spots[i] << endl;
    }
    cout << "\nwith a value of " << max << endl;
  }
  return;
}

void betweennessCentralityEdge(vector<vector<Path> > paths,Graph g)
{
  int nodeSize=paths.size();
  int edgeSize=g.edges.size();
  vector<int> betweennessValues;

  for (int k = 0; k < edgeSize; ++k)
  {
    int count = 0;
    for (int i = 0; i < nodeSize; ++i)
    {   
      for (int j = 0; j < nodeSize; ++j)
      {
        for (int pants = 0; pants < paths[i][j].edges.size(); ++pants)
        {
          if(paths[i][j].edges[pants].source.name==g.edges[k].source.name&&paths[i][j].edges[pants].target.name==g.edges[k].target.name&&paths[i][j].edges[pants].weight==g.edges[k].weight)
          {
            count++;
            pants = INT_MAX;//kick it outside of pants loop
          }
        }     
      }
    }
    betweennessValues.push_back(count);
  }

  string stuff;
  if(g.directed)
  {
    stuff = "UnweightedDirectedBetweennessEdgeDistribution.csv";
  }
  else
  {
    stuff= "UnweightedUndirectedBetweennessEdgeDistribution.csv";
  }

  ofstream outFile(stuff.c_str());
  for (int i = 0; i < betweennessValues.size(); ++i)
  {
    outFile << i << "," << betweennessValues[i] << endl;
  }
  outFile.close();

  vector<Edge> spots;
  int max = 0;
  for (int i = 0; i < betweennessValues.size(); ++i)
  {
    if(betweennessValues[i]>max)
      max=betweennessValues[i];
  }

  for (int i = 0; i < betweennessValues.size(); ++i)
  {
    if(betweennessValues[i]==max)
      spots.push_back(paths[i][0].edges[0]);
  }

  if(spots.size()==1)
  {
    cout << "The edge with the highest weighted betweenness value is " << spots[0] << " with a value of " << max << "!"<<endl<<endl;
  }
  else
  {
    cout << "The edges with the highest weighted betweenness value are:" << endl;
    for (int i = 0; i < spots.size(); ++i)
    {
      cout << spots[i] << endl;
    }
    cout << "\nwith a value of " << max << endl;
  }
  return;
}

void betweennessCentralityEdgeWeighted(vector<vector<Path> > paths,Graph g)
{
  int nodeSize=paths.size();
  int edgeSize=g.edges.size();
  vector<int> betweennessValues;

  for (int k = 0; k < edgeSize; ++k)
  {
    double count = 0;
    for (int i = 0; i < nodeSize; ++i)
    {   
      for (int j = 0; j < nodeSize; ++j)
      {
        for (int pants = 0; pants < paths[i][j].edges.size(); ++pants)
        {
          if(paths[i][j].edges[pants].source.name==g.edges[k].source.name&&paths[i][j].edges[pants].target.name==g.edges[k].target.name&&paths[i][j].edges[pants].weight==g.edges[k].weight)
          {
            count++;
            pants = INT_MAX;//kick it outside of pants loop
          }
        }     
      }
    }
    double weightedCount =  (count/g.edges[k].weight);
    betweennessValues.push_back(weightedCount);
  }

  string stuff;
  if(g.directed)
  {
    stuff = "UnweightedDirectedBetweennessEdgeWeightedDistribution.csv";
  }
  else
  {
    stuff= "UnweightedUndirectedBetweennessEdgeWeightedDistribution.csv";
  }

  ofstream outFile(stuff.c_str());
  for (int i = 0; i < betweennessValues.size(); ++i)
  {
    outFile << i << "," << betweennessValues[i] << endl;
  }
  outFile.close();

  vector<Edge> spots;
  int max = 0;
  for (int i = 0; i < betweennessValues.size(); ++i)
  {
    if(betweennessValues[i]>max)
      max=betweennessValues[i];
  }

  for (int i = 0; i < betweennessValues.size(); ++i)
  {
    if(betweennessValues[i]==max)
      spots.push_back(paths[i][0].edges[0]);
  }

  if(spots.size()==1)
  {
    cout << "The edge with the highest betweenness value is " << spots[0] << " with a value of " << max << "!"<<endl<<endl;
  }
  else
  {
    cout << "The edges with the highest betweenness value are:" << endl;
    for (int i = 0; i < spots.size(); ++i)
    {
      cout << spots[i] << endl;
    }
    cout << "\nwith a value of " << max << endl;
  }
  return;
}

void communityDetection(vector<vector<Path> > paths,Graph g)
{
  int nodeSize=paths.size();
  int edgeSize=g.edges.size();
  vector<int> betweennessValues;

  string stuff;
  if(g.directed&&g.weighted)
  {
    stuff = "communityDirectedUnweighted.csv";
  }
  else
  {
    stuff= "communityUndirectedUnweighted.csv";
  }

  ofstream outFile(stuff.c_str());

  outFile << "Graph Diameter" << endl;

  for (int k = 0; k < edgeSize; ++k)
  {
    int count = 0;
    for (int i = 0; i < nodeSize; ++i)
    {   
      for (int j = 0; j < nodeSize; ++j)
      {
        for (int pants = 0; pants < paths[i][j].edges.size(); ++pants)
        {
          if(paths[i][j].edges[pants].source.name==g.edges[k].source.name&&paths[i][j].edges[pants].target.name==g.edges[k].target.name&&paths[i][j].edges[pants].weight==g.edges[k].weight)
          {
            count++;
            pants = INT_MAX;//kick it outside of pants loop
          }
        }     
      }
    }
    betweennessValues.push_back(count);
  }

  vector<Edge> newGraphEdges;
  int maxE = 0;
  for (int i = 0; i < edgeSize; ++i)
  {
    if(betweennessValues[i]>maxE)
      maxE = betweennessValues[i];
  }

  for (int i = 0; i < edgeSize; ++i)
  {
    if(betweennessValues[i]!=maxE)
    {
      newGraphEdges.push_back(g.edges[i]);
    }
  }

  Graph newGraph("newGraph",g.directed);
  for (int i = 0; i < newGraphEdges.size(); ++i)
  {
    newGraph.addEdge(newGraphEdges[i].source,newGraphEdges[i].target,newGraphEdges[i].weight);
  }

  vector<Path> spots;
  int max=0;

  for (int i = 0; i < nodeSize; ++i)
  {
    for (int j = 0; j < nodeSize; ++j)
    {
      if(paths[i][j].exist()&&paths[i][j].getWeight()>max)
        max=paths[i][j].getWeight();
    }
  }
  for (int i = 0; i < nodeSize; ++i)
  {
    for (int j = 0; j < nodeSize; ++j)
    {
      if(paths[i][j].getWeight()==max)
        spots.push_back(paths[i][j]);
    }
  }

  outFile << spots[0].getWeight() <<endl;

//////////////////////////////////////////////////////////////////////////////////END ONE
  cout << "End One" << endl;
  betweennessValues.clear();

  edgeSize=newGraph.edges.size();

  for (int k = 0; k < edgeSize; ++k)
  {
    int count = 0;
    for (int i = 0; i < nodeSize; ++i)
    {   
      for (int j = 0; j < nodeSize; ++j)
      {
        for (int pants = 0; pants < paths[i][j].edges.size(); ++pants)
        {
          if(paths[i][j].edges[pants].source.name==g.edges[k].source.name&&paths[i][j].edges[pants].target.name==g.edges[k].target.name&&paths[i][j].edges[pants].weight==g.edges[k].weight)
          {
            count++;
            pants = INT_MAX;//kick it outside of pants loop
          }
        }     
      }
    }
    betweennessValues.push_back(count);
  }

  newGraphEdges.clear();
  maxE = 0;
  for (int i = 0; i < edgeSize; ++i)
  {
    if(betweennessValues[i]>maxE)
      maxE = betweennessValues[i];
  }

  for (int i = 0; i < edgeSize; ++i)
  {
    if(betweennessValues[i]!=maxE)
    {
      newGraphEdges.push_back(g.edges[i]);
    }
  }

  newGraph = Graph("newGraph",g.directed);
  for (int i = 0; i < newGraphEdges.size(); ++i)
  {
    newGraph.addEdge(newGraphEdges[i].source,newGraphEdges[i].target,newGraphEdges[i].weight);
  }

  spots.clear();
  max=0;

  for (int i = 0; i < nodeSize; ++i)
  {
    for (int j = 0; j < nodeSize; ++j)
    {
      if(paths[i][j].exist()&&paths[i][j].getWeight()>max&&newGraph.find(paths[i][j]))
        max=paths[i][j].getWeight();
    }
  }
  for (int i = 0; i < nodeSize; ++i)
  {
    for (int j = 0; j < nodeSize; ++j)
    {
      if(paths[i][j].getWeight()==max)
        spots.push_back(paths[i][j]);
    }
  }

  outFile << spots[0].getWeight() <<endl;
//////////////////////////////////////////////////////////////////////////////////END TWO
  cout << "End Two" << endl; 
  betweennessValues.clear(); 
  edgeSize=newGraph.edges.size();

  for (int k = 0; k < edgeSize; ++k)
  {
    int count = 0;
    for (int i = 0; i < nodeSize; ++i)
    {   
      for (int j = 0; j < nodeSize; ++j)
      {
        for (int pants = 0; pants < paths[i][j].edges.size(); ++pants)
        {
          if(paths[i][j].edges[pants].source.name==g.edges[k].source.name&&paths[i][j].edges[pants].target.name==g.edges[k].target.name&&paths[i][j].edges[pants].weight==g.edges[k].weight)
          {
            count++;
            pants = INT_MAX;//kick it outside of pants loop
          }
        }     
      }
    }
    betweennessValues.push_back(count);
  }

  newGraphEdges.clear();
  maxE = 0;
  for (int i = 0; i < edgeSize; ++i)
  {
    if(betweennessValues[i]>maxE)
      maxE = betweennessValues[i];
  }

  for (int i = 0; i < edgeSize; ++i)
  {
    if(betweennessValues[i]!=maxE)
    {
      newGraphEdges.push_back(g.edges[i]);
    }
  }

  newGraph = Graph("newGraph",g.directed);
  for (int i = 0; i < newGraphEdges.size(); ++i)
  {
    newGraph.addEdge(newGraphEdges[i].source,newGraphEdges[i].target,newGraphEdges[i].weight);
  }

  spots.clear();
  max=0;

  for (int i = 0; i < nodeSize; ++i)
  {
    for (int j = 0; j < nodeSize; ++j)
    {
      if(paths[i][j].exist()&&paths[i][j].getWeight()>max&&newGraph.find(paths[i][j]))
        max=paths[i][j].getWeight();
    }
  }
  for (int i = 0; i < nodeSize; ++i)
  {
    for (int j = 0; j < nodeSize; ++j)
    {
      if(paths[i][j].getWeight()==max)
        spots.push_back(paths[i][j]);
    }
  }

  outFile << spots[0].getWeight() <<endl;
//////////////////////////////////////////////////////////////////////////////////END THREE
  cout << "End Three" << endl;
  betweennessValues.clear();
  edgeSize=newGraph.edges.size();

  for (int k = 0; k < edgeSize; ++k)
  {
    int count = 0;
    for (int i = 0; i < nodeSize; ++i)
    {   
      for (int j = 0; j < nodeSize; ++j)
      {
        for (int pants = 0; pants < paths[i][j].edges.size(); ++pants)
        {
          if(paths[i][j].edges[pants].source.name==g.edges[k].source.name&&paths[i][j].edges[pants].target.name==g.edges[k].target.name&&paths[i][j].edges[pants].weight==g.edges[k].weight)
          {
            count++;
            pants = INT_MAX;//kick it outside of pants loop
          }
        }     
      }
    }
    betweennessValues.push_back(count);
  }

  newGraphEdges.clear();
  maxE = 0;
  for (int i = 0; i < edgeSize; ++i)
  {
    if(betweennessValues[i]>maxE)
      maxE = betweennessValues[i];
  }

  for (int i = 0; i < edgeSize; ++i)
  {
    if(betweennessValues[i]!=maxE)
    {
      newGraphEdges.push_back(g.edges[i]);
    }
  }

  newGraph = Graph("newGraph",g.directed);
  for (int i = 0; i < newGraphEdges.size(); ++i)
  {
    newGraph.addEdge(newGraphEdges[i].source,newGraphEdges[i].target,newGraphEdges[i].weight);
  }

  spots.clear();
  max=0;

  for (int i = 0; i < nodeSize; ++i)
  {
    for (int j = 0; j < nodeSize; ++j)
    {
      if(paths[i][j].exist()&&paths[i][j].getWeight()>max&&newGraph.find(paths[i][j]))
        max=paths[i][j].getWeight();
    }
  }
  for (int i = 0; i < nodeSize; ++i)
  {
    for (int j = 0; j < nodeSize; ++j)
    {
      if(paths[i][j].getWeight()==max)
        spots.push_back(paths[i][j]);
    }
  }

  outFile << spots[0].getWeight() <<endl;
//////////////////////////////////////////////////////////////////////////////////END FOUR
  cout << "End Four" << endl;
  betweennessValues.clear();
  edgeSize=newGraph.edges.size();

  for (int k = 0; k < edgeSize; ++k)
  {
    int count = 0;
    for (int i = 0; i < nodeSize; ++i)
    {   
      for (int j = 0; j < nodeSize; ++j)
      {
        for (int pants = 0; pants < paths[i][j].edges.size(); ++pants)
        {
          if(paths[i][j].edges[pants].source.name==g.edges[k].source.name&&paths[i][j].edges[pants].target.name==g.edges[k].target.name&&paths[i][j].edges[pants].weight==g.edges[k].weight)
          {
            count++;
            pants = INT_MAX;//kick it outside of pants loop
          }
        }     
      }
    }
    betweennessValues.push_back(count);
  }

  newGraphEdges.clear();
  maxE = 0;
  for (int i = 0; i < edgeSize; ++i)
  {
    if(betweennessValues[i]>maxE)
      maxE = betweennessValues[i];
  }

  for (int i = 0; i < edgeSize; ++i)
  {
    if(betweennessValues[i]!=maxE)
    {
      newGraphEdges.push_back(g.edges[i]);
    }
  }

  newGraph = Graph("newGraph",g.directed);
  for (int i = 0; i < newGraphEdges.size(); ++i)
  {
    newGraph.addEdge(newGraphEdges[i].source,newGraphEdges[i].target,newGraphEdges[i].weight);
  }

  spots.clear();
  max=0;

  for (int i = 0; i < nodeSize; ++i)
  {
    for (int j = 0; j < nodeSize; ++j)
    {
      if(paths[i][j].exist()&&paths[i][j].getWeight()>max&&newGraph.find(paths[i][j]))
        max=paths[i][j].getWeight();
    }
  }
  for (int i = 0; i < nodeSize; ++i)
  {
    for (int j = 0; j < nodeSize; ++j)
    {
      if(paths[i][j].getWeight()==max)
        spots.push_back(paths[i][j]);
    }
  }

  outFile << spots[0].getWeight() <<endl;
//////////////////////////////////////////////////////////////////////////////////END Five
  cout << "End Five" << endl;
  return;
}