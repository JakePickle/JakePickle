#include <string>

using namespace std;

#ifndef NODE_H
#define NODE_H

class Node
{
  public:

    //Variables
    string name;
    int ID;
    int inDegree;
    int outDegree;

    //Constructors
    Node(){inDegree=0;outDegree=0;};
    Node(string n);
};

#endif