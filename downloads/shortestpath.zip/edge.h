#include "node.h"

using namespace std;

#ifndef EDGE_H
#define EDGE_H

class Edge
{
  public:

    //Variables
    Node source;
    Node target;
    int weight;

    //Constructors
    Edge(){};
    Edge(Node &src, Node &tgt, int wght = 1):source(src),target(tgt),weight(wght){};
    
    //Desc: Prints an edge.
    //Pre: None.
    //Post: Outputs to O-stream.
    //Return: O-stream.
    friend ostream& operator<< (ostream& o, Edge e)
    {
      o<<"("<<e.source.name<<"-"<<e.target.name<<"):";
      o<<" ["<<e.weight<<"]";
      return o;
    }
};

#endif