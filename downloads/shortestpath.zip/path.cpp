#include "path.h"

using namespace std;

Path::Path()
{
  weight=INT_MAX;
  exists=false;
}

Path::Path(Node &src)
{
  source=src;
  target=src;
  weight=0;
  exists=true;
}

Path::Path(Node &src, Node &dest, Edge &edg):source(src),target(dest)
{
  edges.push_back(edg);
  weight = edg.weight;
  exists=true;
}

Path::Path(Node src, Node dest, vector<Edge> edgs):source(src),target(dest)
{
  weight = 0;
  for (int i = 0; i < edgs.size(); ++i)
  {
    edges.push_back(edgs[i]);
    weight+=edgs[i].weight;
  }
  exists=true;
}

void Path::addEdge(Edge edg)
{
  edges.push_back(edg);
  weight+=edg.weight;
  return;
}

int Path::getWeight()
{
  return weight;
}

vector<Edge> Path::getEdges()
{
  return edges;
}

bool Path::find(Edge key)
{
  for(int i=0;i<edges.size();i++)
    if((edges[i].source.name==key.source.name)&&(edges[i].target.name==key.target.name)&&(edges[i].weight==key.weight))
      return true;
  return false;
}

bool operator< (Path& lhs, Path& rhs)
{
  return lhs.getWeight()<rhs.getWeight();
}

bool operator> (Path& lhs, Path& rhs)
{
  return rhs.getWeight()<lhs.getWeight();
}

bool operator<= (Path& lhs, Path& rhs)
{
  return lhs.getWeight()<=rhs.getWeight();
}

bool operator>= (Path& lhs, Path& rhs)
{
  return rhs.getWeight()<=lhs.getWeight();
}

Path operator+ (Path lhs, Path rhs)
{
  for(int i=0;i<rhs.getEdges().size();i++)
    lhs.addEdge(rhs.getEdges()[i]);
  lhs.target = rhs.target;
  return lhs;
}

ostream& operator<< (ostream& o, Path p)
{
  if(!p.exist())
    o<<"NULL";
  else
  {
    if(p.edges.size()==0)
      return o<<"Self Loop ["<<p.getWeight()<<"]";
    for(int i=0;i<p.edges.size();i++)
      o<<"("<<p.edges[i].source.ID+1<<"-"<<p.edges[i].target.ID+1<<"):";
    o<<" ["<<p.getWeight()<<"]";
  }
  return o;
}

Path& Path::operator= (const Path &rhs)
{
  weight = 0;
  edges.clear();
  for (int i = 0; i < rhs.edges.size(); ++i)
    if(!find(rhs.edges[i]))
      addEdge(rhs.edges[i]);
  source = rhs.source;
  target = rhs.target;
  exists=true;
  return *this;
}