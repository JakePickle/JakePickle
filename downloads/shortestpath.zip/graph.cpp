#include "graph.h"

using namespace std;

void Graph::getInDegree()
{
  for(int i=0;i<edges.size();i++)
  {
    if(find(edges[i].target)==false)
    {
      nodes.push_back(edges[i].target);
    }
    for(int j=0;j<nodes.size();j++)
    {
      if(nodes[j].name==edges[i].target.name)
      {
        if(weighted)
          nodes[j].inDegree+=edges[i].weight;
        else
          nodes[j].inDegree++;
      }
    }
  }
  return;
}

void Graph::getOutDegree()
{
  for(int i=0;i<edges.size();i++)
  {
    if(find(edges[i].source)==false)
    {
      nodes.push_back(edges[i].source);
    }
    for(int j=0;j<nodes.size();j++)
    {
      if(nodes[j].name==edges[i].source.name)
      {
        if(weighted)
          nodes[j].outDegree+=edges[i].weight;
        else
          nodes[j].outDegree++;
      }
    }
  }
  return;
}

bool Graph::find(Node key)
{
  for(int i=0;i<nodes.size();i++)
    if(nodes[i].name==key.name)
      return true;
  return false;
}

bool Graph::find(Edge key)
{
  for(int i=0;i<edges.size();i++)
    if((edges[i].source.name==key.source.name)&&(edges[i].target.name==key.target.name)&&(edges[i].weight==key.weight))
      return true;
  return false;
}

bool Graph::find(Path key)
{
  vector<bool> existInPath;
  bool retVal=true;
  for (int k = 0; k < key.edges.size(); ++k)
    existInPath.push_back(false);
  for (int k = 0; k < key.edges.size(); ++k)
    existInPath[k]=(find(key.edges[k]));
  for (int k = 0; k < existInPath.size(); ++k)
    retVal = (retVal&&existInPath[k]);
  return retVal;
}

void Graph::addEdge(Node src, Node tgt, int wt)
{
  if(wt!=1)
    weighted = true;
  Edge e(src,tgt,wt);
  if(!find(e))
    edges.push_back(e);

  if(!directed)
  {
    Edge e(tgt,src,wt);
    if(!find(e))
      edges.push_back(e);
  }

  if(!find(src))
    nodes.push_back(src);
  if(!find(tgt))
    nodes.push_back(tgt);
  return;
}