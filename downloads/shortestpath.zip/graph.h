#include "path.h"

using namespace std;

#ifndef GRAPH_H
#define GRAPH_H

class Graph
{
  public:

    //Variables
    vector<Edge> edges;
    vector<Node> nodes;
    bool weighted;
    bool directed;
    string name;

    //Constructors
    Graph():name("name"),directed(true),weighted(false){};
    Graph(const string &name,const bool &dir):name(name),directed(dir),weighted(false){};

    //Desc: Sets all the 'nodes' in degrees.
    //Pre: None.
    //Post: All the 'nodes' in degrees are set.
    //Return: Void.
    void getInDegree();

    //Desc: Sets all the 'nodes' out degrees.
    //Pre: None.
    //Post: All the 'nodes' out degrees are set.
    //Return: Void.
    void getOutDegree();

    //Desc: Checks if the Node is in the graph.
    //Pre: None.
    //Post: Returns true if Node 'key' was found.
    //Return: Boolean.
    bool find(Node key);

    //Desc: Checks if the Edge is in the graph.
    //Pre: None.
    //Post: Returns true if Edge 'key' was found.
    //Return: Boolean.
    bool find(Edge key);

    //Desc: Checks if the Path is in the graph.
    //Pre: None.
    //Post: Returns true if Path 'key' was found.
    //Return: Boolean.
    bool find(Path key);

    //Desc: Adds an edge to the graph.
    //Pre: None.
    //Post: Filling 'edges'.
    //Return: Void.
    void addEdge(Node src, Node tgt, int wt=1);
};

#endif