#include "node.h"

using namespace std;

Node::Node(string n)
{
  name = n;
  inDegree=0;
  outDegree=0;
}