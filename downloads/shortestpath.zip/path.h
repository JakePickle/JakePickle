#include <climits>
#include <iostream>
#include <vector>
#include "edge.h"

using namespace std;

#ifndef PATH_H
#define PATH_H

class Path
{
  private: 

    //Variables 
    int weight;
    bool exists;   

  public:

    //Variables
    vector<Edge> edges;
    Node source;
    Node target;

    //Constructors
    Path();
    Path(Node &src);
    Path(Node &src, Node &dest, Edge &edg);
    Path(Node src, Node dest, vector<Edge> edgs);
    
    //Desc: Accessor for exists.
    //Pre: None.
    //Post: None.
    //Return: Boolean.
    bool exist(){return exists;};
    
    //Desc: Checks if the edge 'key' exists in the path.
    //Pre: None.
    //Post: Returns true if the edge exists in the path.
    //Return: Boolean.
    bool find(Edge key);
    
    //Desc: Adds the edge 'edg' to the path.
    //Pre: None.
    //Post: 'edg' is added to the path.
    //Return: Void.
    void addEdge(Edge edg);
    
    //Desc: Accessor for weight.
    //Pre: None.
    //Post: None.
    //Return: Integer.
    int getWeight();
    
    //Desc: Accessor for edges.
    //Pre: None.
    //Post: None.
    //Return: Vector of Edges.
    vector<Edge> getEdges();
    
    //Desc: Comparator for path weights.
    //Pre: None.
    //Post: Returns true if the weight of 'lhs' was less than the weight of 'rhs'.
    //Return: Boolean.
    friend bool operator< (Path& lhs, Path& rhs);
    
    //Desc: Comparator for path weights.
    //Pre: None.
    //Post: Returns true if the weight of 'lhs' was greater than the weight of 'rhs'.
    //Return: Boolean.
    friend bool operator> (Path& lhs, Path& rhs);
    
    //Desc: Comparator for path weights.
    //Pre: None.
    //Post: Returns true if the weight of 'lhs' was less than or equal to the weight of 'rhs'.
    //Return: Boolean.
    friend bool operator<= (Path& lhs, Path& rhs);
    
    //Desc: Comparator for path weights.
    //Pre: None.
    //Post: Returns true if the weight of 'lhs' was greater than or equal to the weight of 'rhs'.
    //Return: Boolean.
    friend bool operator>= (Path& lhs, Path& rhs);
    
    //Desc: Adds two paths together.
    //Pre: None.
    //Post: 'rhs' got added to 'lhs'.
    //Return: Path.
    friend Path operator+ (Path lhs, Path rhs);
    
    //Desc: Prints all the edges in the path.
    //Pre: None.
    //Post: Outputs to O-stream.
    //Return: O-stream.
    friend ostream& operator<< (ostream& o, Path p);
    
    //Desc: Equals operator.
    //Pre: None.
    //Post: Assigns the 'rhs' variables to 'this' variables.
    //Return: Path.
    Path& operator= (const Path &rhs);
};

#endif